'use strict';

const https = require('https');
const options = {
    host: 'https://stat-hh-mls-user-dev-orma.corp.statista.com/',
    port: 443,
    path: '/sesCallback/',
    method: 'POST',
    rejectUnauthorized: false,
    headers: {'Content-Type': 'application/json'}
};

/**
 * Pass the data to send as `event.data`, and the request options as
 * `event.options`. For more information see the HTTPS module documentation
 * at https://nodejs.org/api/https.html.
 *
 * Will succeed with the response body.
 */
exports.handler = (event, context, callback) => {
    var message = JSON.parse(event['Records'][0]['Sns']['Message']);
    var emailAddress = message.mail.destination.toString();
    var bounceType = message.bounce.bounceType.toString();
    
    if (bounceType === 'Permanent') {
        const req = https.request(options, (res) => {
            let body = '';
            res.setEncoding('utf8');
            res.on('data', (chunk) => body += chunk);
            res.on('end', () => {
                if (res.headers['content-type'] === 'application/json') {
                    body = JSON.parse(body);
                }
                callback(null, body);
            });
        });
        req.on('error', callback);
        req.write(JSON.stringify(message));
        req.end();
        
        console.log(emailAddress + ' marked as bouncer - source: ' + message.mail.source.toString());        
    }
};

// var AWS = require('aws-sdk');

// exports.handler = function (event, context, callback) {
//     AWS.config.update({ region: 'eu-central-1' });
//     var sqs = new AWS.SQS({ apiVersion: '2012-11-05' });

//     var params = {
//         DelaySeconds: 10,
//         MessageAttributes: {
//             "Hello": {
//                 DataType: "String",
//                 StringValue: "From Paris with love"
//             },
//         },
//         MessageBody: "Information about current NY Times fiction bestseller for week of 12/11/2016.",
//         QueueUrl: "http://host.docker.internal:4566/000000000000/s3-notifications"
//     };

//     sqs.sendMessage(params, function (err, data) {
//         if (err) {
//             console.log("\n*** Bla Bla Error ***\n", err);
//             return;
//         }
//         console.log("\n*** Bla Bla Success ***\n", data.MessageId);
//     });
// };
